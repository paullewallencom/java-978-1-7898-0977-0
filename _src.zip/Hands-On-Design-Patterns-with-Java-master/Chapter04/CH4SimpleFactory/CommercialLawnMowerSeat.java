package CH4SimpleFactory;

public class CommercialLawnMowerSeat extends LawnMowerSeat {

    public CommercialLawnMowerSeat() {

        System.out.println("Commercial lawnmower seat with roll bar created.");
    }
}
