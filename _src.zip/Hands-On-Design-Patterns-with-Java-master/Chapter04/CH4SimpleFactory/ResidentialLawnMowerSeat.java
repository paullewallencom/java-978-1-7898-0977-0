package CH4SimpleFactory;

public class ResidentialLawnMowerSeat extends LawnMowerSeat {

    public ResidentialLawnMowerSeat() {

        System.out.println("Residential lawnmower seat with seat belt created.");

    }
}
