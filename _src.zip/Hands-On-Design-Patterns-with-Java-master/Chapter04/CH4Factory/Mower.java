package CH4Factory;

public interface Mower {
    void mow();
}
