package CH4Factory;

public class Riding implements Mower {

    @Override
    public void mow() {
        System.out.println("Riding mowers provide safety and comfort.");
    }
}
