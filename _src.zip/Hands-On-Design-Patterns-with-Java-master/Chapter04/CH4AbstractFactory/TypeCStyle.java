package CH4AbstractFactory;

public class TypeCStyle implements Style {

    public String getStyle() {

        return "[Type C] Style:\t\tExtended Trip";
    }
}