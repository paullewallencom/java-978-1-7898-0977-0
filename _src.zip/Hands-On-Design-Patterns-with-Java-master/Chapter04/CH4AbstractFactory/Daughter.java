package CH4AbstractFactory;

public class Daughter {

    public static void main(String[] args) {
        Mother mom = new Mother();
    }
}
