package CH4AbstractFactory;

public class TypeAKitchen implements Kitchen {

    public String getKitchen() {

        return "[Type A] Kitchen:\tFull";
    }
}