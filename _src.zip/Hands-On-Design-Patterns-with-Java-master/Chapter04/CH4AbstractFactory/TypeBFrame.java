package CH4AbstractFactory;

public class TypeBFrame implements Frame {

    public String getFrame() {

        return "[Type B] Frame:\t\tCamper Van";
    }
}
