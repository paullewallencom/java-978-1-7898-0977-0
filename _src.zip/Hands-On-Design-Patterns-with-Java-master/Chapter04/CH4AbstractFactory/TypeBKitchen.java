package CH4AbstractFactory;

public class TypeBKitchen implements Kitchen {

    public String getKitchen() {

        return "[Type B] Kitchen:\tCompact";
    }
}