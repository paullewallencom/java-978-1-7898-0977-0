package CH4AbstractFactory;

public class TypeBStyle implements Style {

    public String getStyle() {

        return "[Type B] Style:\t\tWeekender";
    }
}