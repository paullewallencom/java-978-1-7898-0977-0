package CH4AbstractFactory;

public interface Engine {
    public String getEngine();
}
