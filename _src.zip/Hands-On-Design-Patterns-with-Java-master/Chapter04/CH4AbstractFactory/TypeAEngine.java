package CH4AbstractFactory;

public class TypeAEngine implements Engine {

    public String getEngine() {

        return "[Type A] Engine:\tFord V10";
    }
}