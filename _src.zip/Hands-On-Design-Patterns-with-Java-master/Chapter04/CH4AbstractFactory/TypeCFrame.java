package CH4AbstractFactory;

public class TypeCFrame implements Frame {

    public String getFrame() {

        return "[Type C] Frame:\t\tTruck";
    }
}
