package CH3Observer;

public interface Observer {
}
