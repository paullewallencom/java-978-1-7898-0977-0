package CH5Flyweight;

public interface MattressInterface {

    void print();
}
