package CH5Adapter;

public class Lot {

    // class variables
    public double length;
    public double width;
}
