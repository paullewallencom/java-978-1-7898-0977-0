package CH5Decorator;

abstract class Printer {
    public abstract void flushBuffer();
}
