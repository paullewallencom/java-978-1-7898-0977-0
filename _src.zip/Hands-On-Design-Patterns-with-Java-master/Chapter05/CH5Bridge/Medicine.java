package CH5Bridge;

public interface Medicine {

    void administerMedication(int amount);
}
